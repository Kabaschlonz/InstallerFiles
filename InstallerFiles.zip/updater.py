import requests
import zipfile
import os
import subprocess
import sys
import shutil
import tempfile

# Temporären Ordner erstellen
tmp_dir = tempfile.mkdtemp()

# Arbeitsverzeichnis auf Updater-Ordner setzen
os.chdir(os.path.dirname(os.path.abspath(__file__)))

UPDATE_URL = "https://raw.githubusercontent.com/kabaschlonz/updater/main/updates/update.zip"

zip_path = "update.zip"
extract_path = os.path.abspath("../Begleiterapp/update_package")

# ZIP herunterladen
r = requests.get(UPDATE_URL)
with open(zip_path, "wb") as f:
    f.write(r.content)

# Ordner erstellen, falls er nicht existiert
os.makedirs(extract_path, exist_ok=True)

# ZIP entpacken
with zipfile.ZipFile(zip_path, "r") as zip_ref:
    zip_ref.extractall(extract_path)

print(os.listdir(extract_path))

# ZIP löschen
os.remove(zip_path)

# Hauptprogramm neu starten
subprocess.Popen([sys.executable, os.path.join(extract_path, "main.py")])