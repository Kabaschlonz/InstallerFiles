import subprocess
import sys

subprocess.Popen(["python", "update_package/main.py"])
sys.exit()
