import subprocess
import sys

subprocess.Popen(["python", "resources/main.py"])
sys.exit()
